module.exports = function (arr1, arr2) {
    if (arr1.length === arr2.length) {
        for (let i = 0; i < arr1.length; i++) {
            if (arr1[i] !== arr2[i] || typeof arr1[i] !== typeof arr2[i]) {
                return false;
            }
        }
        return true;
    }
    return false;
}